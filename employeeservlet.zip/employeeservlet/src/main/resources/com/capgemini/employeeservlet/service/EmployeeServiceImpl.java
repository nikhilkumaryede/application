package com.capgemini.servletemployee.service;

import java.util.List;

import com.capgemini.servletemployee.dao.EmployeeDAO;
import com.capgemini.servletemployee.dao.EmployeeDAOImpl;
import com.capgemini.servletemployee.dto.EmployeeBean;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO empdao=new EmployeeDAOImpl();

	public EmployeeBean getEmployeeByid(int Id) {
		// TODO Auto-generated method stub
		return empdao.getEmployeeByid(Id);
	}

	public boolean addEmployee(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return empdao.addEmployee(bean);
	}

	public boolean updateEmployee(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return empdao.updateEmployee(bean);
	}

	public boolean deleteEmployee(int Id) {
		// TODO Auto-generated method stub
		return empdao.deleteEmployee(Id);
	}

	public List<EmployeeBean> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public EmployeeBean authenticate(int empId, String password) {
		// TODO Auto-generated method stub
		return empdao.authenticate(empId, password);
	}

}
