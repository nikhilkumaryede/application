package com.capgemini.employeeservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.employeeservlet.dto.EmployeeBean;
import com.capgemini.employeeservlet.service.EmployeeService;
import com.capgemini.employeeservlet.service.EmployeeServiceImpl;
@WebServlet("./login")
public class LoginServlet extends HttpServlet {
private EmployeeService service = new EmployeeServiceImpl();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String  empIdVal = req.getParameter("empId");
		int empId = Integer.parseInt(empIdVal);
		String password = req.getParameter("password");
		
		EmployeeBean employeeInfoBean = service.authenticate(empId, password);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("<html>");
		out.print("<body>");
		
		if(employeeInfoBean != null) {
			
			HttpSession httpSession = req.getSession(true);
			httpSession.setAttribute("loggedInEmployeeInfo", employeeInfoBean);
			out.print("<h2 style='color :navy' > WELCOME !!"+ employeeInfoBean.getEmpName()+"</h2>");
			RequestDispatcher dispatcher= req.getRequestDispatcher("./homePage.html");
			dispatcher.include(req,resp);
			
		}else {
			out.print("<h1 style='color :red' > Invaild Credentials !!</h1>");
			RequestDispatcher dispatcher= req.getRequestDispatcher("./loginForm.html");
			dispatcher.include(req,resp);
		}
		
		out.print("<html>");
		out.print("<body>");
		
		
	}

}
